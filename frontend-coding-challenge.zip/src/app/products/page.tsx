import { Products } from "@/views/products";

export default function ProductsRoot() {
  return <Products />;
}
