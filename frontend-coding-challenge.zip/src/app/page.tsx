import { Home } from "@/views/home";

export default function HomeRoot() {
  return <Home />;
}
