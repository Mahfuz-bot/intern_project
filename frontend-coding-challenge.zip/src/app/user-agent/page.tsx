import { UserAgent } from "@/views/userAgent";

const UserAgentRoot = () => {
  return <UserAgent />;
};

export default UserAgentRoot;
